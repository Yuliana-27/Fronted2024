import { Button } from "./Button"

export const ButtonsRow = () => {
    return(
        <tr>
            <td>
                <Button/>
            </td>
        </tr>
    )
}