export const buttonsClasses ={
numeric: 'btn btn-outline-dark w-100',
operator: 'btn btn-outline-secondary w-100',
}